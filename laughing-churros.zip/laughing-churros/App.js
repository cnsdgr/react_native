import React,{useState,useEffect} from 'react';
import {StyleSheet,Text,View,TouchableOpacity} from 'react-native';

export default function App(){

  const [sayac,setSayac]=useState(0);
  const [backgroundColor,setBackgroundColor]=useState('white');


  useEffect(()=>{
    if(sayac==5){
      setBackgroundColor("yellow");
    }else if(sayac==(-5)){
      setBackgroundColor("red");

    }else{
      setBackgroundColor("white");
    }

  },[sayac])



return(

  <View style={[styles.container,{backgroundColor}]}>
    

        <TouchableOpacity style={styles.button} 
        onPress={()=>{
          setSayac(sayac+1);
       
        }}>
    <Text style={styles.button_text}>Arttir</Text>
    </TouchableOpacity>

    <Text style={styles.sayac_text}>{sayac}</Text>
  <TouchableOpacity style={styles.button} onPress={()=>{setSayac(sayac-1);

  }}>
    <Text style={styles.button_text}>Azalt</Text>
    </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={()=>setSayac(0)}>
    <Text style={styles.button_text}>Sifirla</Text>
    </TouchableOpacity>
 


  </View>

);
}

const styles=StyleSheet.create({

  container:{
    flex:1,
    backgroundColor:'pink',
    alignItems:'center',
    justifyContent:'center',

  },

  button:{
    backgroundColor:'gray',
    padding:20,
    borderRadius:5,
    marginTop:10,
    width:150,
    height:75,
    alignItems:'center',

  },
  button_text:{
    color:'white',
    fontWeight:'bold',
    fontSize:20,
  },
  sayac_text:{
    fontSize:30,
    fontWeight:'bold',
  }
 

})